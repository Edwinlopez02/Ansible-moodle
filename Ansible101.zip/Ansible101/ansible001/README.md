# Cofiguración de Ansible

## Primer paso, instalación de los servidores web y de archivos.
